const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const BANK = [
 {id:"d1",type:"vocab",q:"Выбери правильное значение слова 既然 (jìrán).",opts:["поскольку; раз уж","несмотря на","внезапно","временно"],a:0,why:"既然 вводит уже установленное условие: «раз уж / поскольку». Часто используется в конструкции 既然……就……。",level:4},
 {id:"d2",type:"grammar",q:"Выбери правильное продолжение: 他既然答应了，……",opts:["就应该做到","但是做到了","因为做到了","虽然答应"],a:0,why:"既然……就…… связывает условие и логичный результат.",level:4},
 {id:"d3",type:"vocab",q:"Что означает 逐渐 (zhújiàn)?",opts:["постепенно","немедленно","случайно","намеренно"],a:0,why:"逐渐 означает «постепенно», «понемногу».",level:4},
 {id:"d4",type:"grammar",q:"Выбери предложение с правильным использованием 即使……也……",opts:["即使下雨，我也要去。","即使下雨，因为我要去。","即使我也下雨要去。","即使下雨，但是也要去。"],a:0,why:"即使……也…… выражает уступку: «даже если…, всё равно…».",level:4},
 {id:"d5",type:"vocab",q:"Выбери значение 维护 (wéihù).",opts:["защищать; поддерживать","объяснять","обменивать","расходовать"],a:0,why:"维护 — защищать, поддерживать, обеспечивать сохранность.",level:4},
 {id:"d6",type:"grammar",q:"Какое слово лучше всего вставить? 这件事对我来说非常……。",opts:["重要","重要地","重要性地","重要了"],a:0,why:"После 非常 ставится прилагательное: 非常重要 — очень важно.",level:4},
 {id:"d7",type:"vocab",q:"Что означает 逐渐增加?",opts:["постепенно увеличиваться","резко уменьшаться","полностью исчезать","временно останавливаться"],a:0,why:"逐渐 — постепенно, 增加 — увеличиваться.",level:4},
 {id:"d8",type:"grammar",q:"Выбери правильный вариант: 除了中文以外，他……英语。",opts:["还会说","才说过","就说着","已经说得"],a:0,why:"除了……以外，还…… — «помимо…, ещё и…».",level:4},
 {id:"d9",type:"vocab",q:"Что означает 责任 (zérèn)?",opts:["ответственность","возможность","результат","отношение"],a:0,why:"责任 — ответственность, обязанность.",level:4},
 {id:"d10",type:"grammar",q:"Выбери корректную конструкцию сравнения: 这本书……那本书有意思。",opts:["比","被","把","对"],a:0,why:"比 используется для сравнений: A 比 B + прилагательное.",level:4},
 {id:"d11",type:"reading",q:"Прочитай: 他虽然工作很忙，但是每天坚持学习汉语。 Почему он продолжает учить китайский?",opts:["Несмотря на занятость, он каждый день упорно учится","Он перестал работать","Он учит китайский только по выходным","Ему не нравится китайский"],a:0,why:"虽然……但是…… — уступительная конструкция. В тексте сказано, что он каждый день坚持学习.",level:4},
 {id:"d12",type:"vocab",q:"Что ближе всего по смыслу к 影响 (yǐngxiǎng)?",opts:["влиять; воздействие","обещать","привыкать","обсуждать"],a:0,why:"影响 может быть глаголом «влиять» и существительным «влияние».",level:4},
 {id:"l1",type:"vocab",q:"Выбери значение 促进 (cùjìn).",opts:["способствовать; стимулировать","отказываться","сравнивать","предупреждать"],a:0,why:"促进 — содействовать развитию, стимулировать.",level:5},
 {id:"l2",type:"grammar",q:"Выбери правильное предложение с 不但……而且……",opts:["他不但会说中文，而且会写汉字。","他不但会说中文，但是会写汉字。","他而且会说中文，不但会写汉字。","他不但中文，而且写汉字会。"],a:0,why:"不但……而且…… соединяет два дополняющих друг друга факта: «не только…, но и…».",level:5}
];
// Перемешиваем позиции правильных ответов: тест не должен подсказывать ключ шаблоном.
BANK.forEach((q, i) => {
  const target = [2, 0, 3, 1, 2, 3, 0, 1, 3, 2, 1, 0, 2, 3][i % 14];
  [q.opts[0], q.opts[target]] = [q.opts[target], q.opts[0]];
  q.a = target;
});
const initial = {
 active:"p1",
 profiles:{
  p1:{name:"Игрок 1",xp:0,streak:0,done:0,diagnostic:null,history:[],due:[]},
  p2:{name:"Игрок 2",xp:0,streak:0,done:0,diagnostic:null,history:[],due:[]}
 },
 settings:{dailyMinutes:60,language:"progressive"}
};
let state = load();
let quiz = null;
let diagIndex = 0;
let diagAnswers = [];
let learnIndex = 0;
let learnAnswers = [];
let battleIndex = 0;
let battleScores = {p1:0,p2:0};
const save=()=>localStorage.setItem("cb_state",JSON.stringify(state));
function load(){try{return {...initial,...JSON.parse(localStorage.getItem("cb_state")||"{}")}}catch{return structuredClone(initial)}}
const me=()=>state.profiles[state.active];
const esc=s=>String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function toast(t){let el=$("#toast");el.textContent=t;el.classList.add("show");setTimeout(()=>el.classList.remove("show"),2200)}
function nav(page){$$(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.page===page));$("#pageTitle").textContent=({dashboard:"Панель управления",learn:"Учебный центр",diagnostic:"Входная диагностика",battle:"Арена соревнований",progress:"Мой прогресс",settings:"Настройки"})[page];render(page);$(".sidebar").classList.remove("open")}
$$(".nav-item").forEach(b=>b.addEventListener("click",()=>nav(b.dataset.page)));
$("#activeProfile").value=state.active;
$("#activeProfile").addEventListener("change",e=>{state.active=e.target.value;save();$("#avatar").textContent=state.active==="p1"?"1":"2";nav("dashboard")});
$("#mobileMenu").onclick=()=>$(".sidebar").classList.toggle("open");
function render(page="dashboard"){if(page==="dashboard")dashboard();if(page==="diagnostic")diagnosticIntro();if(page==="learn")learnPage();if(page==="battle")battlePage();if(page==="progress")progressPage();if(page==="settings")settingsPage()}
function dashboard(){
 const p=me(), done=p.done||0, diag=p.diagnostic;
 $("#appContent").innerHTML=`
 <section class="hero"><div class="hero-copy"><span class="pill">SEASON 01 • НАЧАЛО ПУТИ</span><h1>Твой китайский.<br>Твой уровень. Твоя битва.</h1><p>Сначала определим твои реальные знания, затем построим индивидуальный маршрут от нужного раздела HSK 4 к HSK 5–6.</p><div class="actions"><button class="btn" onclick="nav('${diag?"learn":"diagnostic"}')">${diag?"Продолжить обучение":"Начать диагностику"} →</button><button class="btn secondary" onclick="nav('battle')">Открыть арену</button></div></div><div class="hero-stat"><strong>${p.xp}</strong><span>общий опыт XP</span></div></section>
 <div class="grid stats-grid">
  <div class="card stat-card"><div class="stat-label">Уровень</div><div class="stat-value">${diag?`HSK ${diag.level}`:"—"}</div><div class="stat-note">${diag?"по результатам диагностики":"ожидает тестирования"}</div></div>
  <div class="card stat-card"><div class="stat-label">Опыт</div><div class="stat-value">${p.xp} XP</div><div class="stat-note">+20 XP за урок</div></div>
  <div class="card stat-card"><div class="stat-label">Уроки завершены</div><div class="stat-value">${done}</div><div class="stat-note">всего занятий</div></div>
  <div class="card stat-card"><div class="stat-label">Серия занятий</div><div class="stat-value">${p.streak} 🔥</div><div class="stat-note">дней подряд</div></div>
 </div>
 <div class="grid two-col"><div><div class="section-head"><h2>Твой план на сегодня</h2><span>60 минут</span></div><div class="card">
  ${[["10 мин","Повторение слов","Карточки и интервальное повторение","字"],["15 мин","Новая лексика","Слова по теме текущего модуля","词"],["15 мин","Грамматика","Правило, примеры и практика","文"],["10 мин","Аудирование / чтение","Работа с контекстом","听"],["10 мин","Активная практика","Составление фраз и мини-диалог","说"]].map(x=>`<div class="task"><div class="task-icon">${x[3]}</div><div class="task-info"><b>${x[1]}</b><small>${x[2]}</small></div><span class="task-time">${x[0]}</span></div>`).join("")}
  <div class="actions"><button class="btn" onclick="nav('learn')">Начать учебный блок</button></div></div></div>
 <div><div class="section-head"><h2>Твой маршрут</h2><span>HSK 3.0</span></div><div class="card"><div class="stat-label">Текущая цель</div><h3 style="margin:8px 0">${diag?`Закрепить HSK ${diag.level}`:"Определить точку входа в HSK 4"}</h3><p class="muted" style="font-size:12px">Система не будет заставлять проходить уже знакомые темы. Диагностика выявит пробелы и предложит персональный порядок занятий.</p><div class="progress-line"><i style="width:${diag?Math.max(8,diag.percent):0}%"></i></div><small class="muted">${diag?`Диагностика: ${diag.percent}% правильных ответов`:"Диагностика ещё не пройдена"}</small><div class="actions"><button class="btn secondary" onclick="nav('progress')">Подробнее о прогрессе</button></div></div></div></div>`;
}
function diagnosticIntro(){
 $("#appContent").innerHTML=`<div class="page-intro"><h1>Входная диагностика</h1><p>Тест оценит словарный запас, грамматику и понимание контекста. Это предварительная адаптивная диагностика, а не официальный экзамен HSK.</p></div>
 <div class="card question-card"><span class="pill">PLACEMENT TEST • HSK 4–5</span><h2 style="margin:13px 0 7px">Найдём твою точку старта</h2><p class="muted">12 заданий разной сложности. Отвечай самостоятельно, без словаря и переводчика. После теста покажем результат и рекомендуем разделы для повторения.</p>
 <div class="grid three-col" style="margin:20px 0"><div class="card"><b>词汇</b><div class="muted">Лексика</div></div><div class="card"><b>语法</b><div class="muted">Грамматика</div></div><div class="card"><b>阅读</b><div class="muted">Чтение</div></div></div>
 <div class="actions"><button class="btn" onclick="startDiagnostic()">Начать тест →</button><button class="btn ghost" onclick="nav('dashboard')">Позже</button></div></div>`;
}
function startDiagnostic(){diagIndex=0;diagAnswers=[];showDiagnosticQuestion()}
function showDiagnosticQuestion(){
 const q=BANK[diagIndex], pct=Math.round(diagIndex/BANK.length*100);
 $("#appContent").innerHTML=`<div class="card question-card"><div class="question-progress"><span>ДИАГНОСТИКА • ВОПРОС ${diagIndex+1}/${BANK.length}</span><span>${pct}%</span></div><div class="progress-line"><i style="width:${pct}%"></i></div><div class="question-text">${esc(q.q)}</div><div class="question-sub">${q.type==="vocab"?"词汇 • Лексика":q.type==="grammar"?"语法 • Грамматика":"阅读 • Чтение"} <span class="pill">HSK ${q.level}</span></div><div class="answers">${q.opts.map((o,i)=>`<button class="answer" onclick="answerDiagnostic(${i})">${["A","B","C","D"][i]}. ${esc(o)}</button>`).join("")}</div><div class="actions"><button class="btn ghost" onclick="nav('dashboard')">Выйти из теста</button></div></div>`;
}
function answerDiagnostic(i){diagAnswers.push(i);diagIndex++;if(diagIndex<BANK.length)showDiagnosticQuestion();else finishDiagnostic()}
function finishDiagnostic(){
 const score=diagAnswers.reduce((n,a,i)=>n+(a===BANK[i].a?1:0),0), pct=Math.round(score/BANK.length*100);
 let level=pct>=83?5:pct>=50?4:4;
 const weak=BANK.filter((q,i)=>diagAnswers[i]!==q.a).map(q=>q.type);
 me().diagnostic={score,total:BANK.length,percent:pct,level,weak:[...new Set(weak)],date:new Date().toISOString()};
 me().xp+=score*5;save();
 $("#appContent").innerHTML=`<div class="card question-card"><span class="pill success">ТЕСТ ЗАВЕРШЁН</span><h1 style="font-size:32px;margin:16px 0 5px">${pct}%</h1><h2>Предварительный результат: ${level===5?"уверенная база HSK 4 / переход к HSK 5":"уровень для старта — HSK 4"}</h2><p class="muted">Правильных ответов: ${score} из ${BANK.length}. Этот результат определяет предварительную точку входа; точность повысится после дополнительных заданий на аудирование, письмо и устную речь.</p><div class="grid two-col" style="margin:20px 0"><div class="card"><b>Что проверено</b><p class="muted">Лексика, грамматика, чтение</p></div><div class="card"><b>Что ещё предстоит оценить</b><p class="muted">Аудирование, письмо, говорение</p></div></div><h3>Следующий шаг</h3><p class="muted">Начни с учебного модуля, а система будет постепенно уточнять твой уровень по результатам занятий.</p><div class="actions"><button class="btn" onclick="nav('learn')">Перейти к обучению →</button><button class="btn secondary" onclick="nav('progress')">Посмотреть результаты</button></div></div>`;
}
function learnPage(){
 const p=me(), lvl=p.diagnostic?.level||4;
 $("#appContent").innerHTML=`<div class="page-intro"><h1>Учебный центр</h1><p>Последовательное обучение с опорой на HSK 3.0. Объяснения на русском, примеры и задания на китайском. По мере роста уровня доля китайского будет увеличиваться.</p></div>
 <div class="grid two-col"><div class="card"><span class="pill">ТВОЙ ТЕКУЩИЙ МАРШРУТ</span><h2>HSK ${lvl} • Модуль 01</h2><p class="muted">Логические связки и выражение условий: 既然……就……、即使……也……、除了……以外……。</p><div class="progress-line"><i style="width:${p.done?Math.min(100,p.done*12):0}%"></i></div><small class="muted">Прогресс модуля: ${Math.min(100,p.done*12)}%</small><div class="actions"><button class="btn" onclick="startLesson()">Начать тренировку</button></div></div><div class="card"><div class="stat-label">Ежедневная структура</div><h3>60 минут фокусированной практики</h3><p class="muted">10 мин повторение • 15 мин лексика • 15 мин грамматика • 10 мин восприятие • 10 мин активное применение.</p><span class="pill success">Адаптивное повторение включено</span></div></div>
 <div class="section-head"><h2>Разделы программы</h2><span>От HSK 4 к HSK 6</span></div><div class="grid three-col">
 ${[["词汇","Лексика","Тематические наборы, активное вспоминание и контекст."],["语法","Грамматика","Структуры, контрастные примеры и собственные предложения."],["听力","Аудирование","Диалоги, короткие сообщения и понимание на слух."],["阅读","Чтение","Тексты по уровням и задания на понимание."],["口语","Говорение","Ролевые ситуации, монологи и пересказ."],["写作","Письмо","Предложения, связные тексты и работа над ошибками."]].map(x=>`<div class="card"><span class="pill">${x[0]}</span><h3>${x[1]}</h3><p class="muted">${x[2]}</p></div>`).join("")}</div>`;
}
function startLesson(){learnIndex=0;learnAnswers=[];showLessonQuestion()}
function showLessonQuestion(){
 const q=BANK.filter(x=>x.level<= (me().diagnostic?.level||4))[learnIndex%BANK.filter(x=>x.level<=(me().diagnostic?.level||4)).length];
 quiz=q;
 $("#appContent").innerHTML=`<div class="card question-card"><div class="question-progress"><span>ТРЕНИРОВКА • ЗАДАНИЕ ${learnIndex+1}/5</span><span>+20 XP за завершение</span></div><div class="question-text">${esc(q.q)}</div><div class="question-sub">${q.type==="vocab"?"Лексика":"Грамматика"} • HSK ${q.level}</div><div class="answers">${q.opts.map((o,i)=>`<button class="answer" onclick="answerLesson(${i})">${["A","B","C","D"][i]}. ${esc(o)}</button>`).join("")}</div><div id="lessonFeedback"></div><div class="actions"><button class="btn ghost" onclick="nav('learn')">Выйти</button></div></div>`;
}
function answerLesson(i){
 const q=quiz, buttons=$$(".answer");buttons.forEach((b,j)=>{b.disabled=true;if(j===q.a)b.classList.add("correct");if(j===i&&i!==q.a)b.classList.add("wrong")});
 $("#lessonFeedback").innerHTML=`<div class="feedback"><b>${i===q.a?"Верно!":"Разберём ошибку"}</b><br>${esc(q.why)}</div><div class="actions"><button class="btn" onclick="nextLesson()">${learnIndex===4?"Завершить блок":"Следующее задание →"}</button></div>`;
 learnAnswers.push(i===q.a);
}
function nextLesson(){learnIndex++;if(learnIndex<5)showLessonQuestion();else{const correct=learnAnswers.filter(Boolean).length;me().xp+=20+correct*5;me().done++;me().history.push({date:new Date().toISOString(),score:correct,total:5});save();$("#appContent").innerHTML=`<div class="card question-card"><span class="pill success">УЧЕБНЫЙ БЛОК ЗАВЕРШЁН</span><h1>${correct}/5</h1><h2>Хорошая работа!</h2><p class="muted">Ты получил ${20+correct*5} XP. Ошибки будут учтены при подборе следующих упражнений.</p><button class="btn" onclick="nav('dashboard')">Вернуться на главную</button></div>`}}
function battlePage(){
 const p1=state.profiles.p1,p2=state.profiles.p2;
 $("#appContent").innerHTML=`<div class="page-intro"><h1>Арена соревнований</h1><p>Два профиля, общий рейтинг и одинаковые задания. Сейчас соревнование работает на одном устройстве; онлайн-дуэли появятся после подключения серверной синхронизации.</p></div>
 <div class="grid two-col"><div class="card"><span class="pill">СЕЗОННЫЙ РЕЙТИНГ</span><table class="table"><thead><tr><th>Место</th><th>Игрок</th><th>XP</th></tr></thead><tbody>${[{...p1,id:"p1"},{...p2,id:"p2"}].sort((a,b)=>b.xp-a.xp).map((p,i)=>`<tr><td class="rank">#${i+1}</td><td>${esc(p.name)}</td><td>${p.xp}</td></tr>`).join("")}</tbody></table></div><div class="card"><span class="pill warning">ЛОКАЛЬНАЯ ДУЭЛЬ</span><h3>Сразитесь в коротком раунде</h3><p class="muted">Игроки по очереди отвечают на один и тот же набор вопросов. За каждый правильный ответ начисляется 10 очков.</p><button class="btn" onclick="startBattle()">Начать дуэль →</button></div></div>`;
}
function startBattle(){battleIndex=0;battleScores={p1:0,p2:0};showBattleTurn("p1")}
function showBattleTurn(pid){
 const q=BANK[(battleIndex)%BANK.length], name=state.profiles[pid].name;
 $("#appContent").innerHTML=`<div class="card question-card"><span class="pill warning">ДУЭЛЬ • ВОПРОС ${battleIndex+1}/5</span><h2 style="margin-top:16px">${esc(name)}, твой ход</h2><div class="question-text">${esc(q.q)}</div><div class="answers">${q.opts.map((o,i)=>`<button class="answer" onclick="battleAnswer('${pid}',${i})">${["A","B","C","D"][i]}. ${esc(o)}</button>`).join("")}</div></div>`;
}
function battleAnswer(pid,i){if(i===BANK[battleIndex%BANK.length].a)battleScores[pid]+=10;if(pid==="p1")showBattleTurn("p2");else{battleIndex++;if(battleIndex<5)showBattleTurn("p1");else finishBattle()}}
function finishBattle(){state.profiles.p1.xp+=battleScores.p1;state.profiles.p2.xp+=battleScores.p2;save();let winner=battleScores.p1===battleScores.p2?"Ничья":battleScores.p1>battleScores.p2?state.profiles.p1.name:state.profiles.p2.name;$("#appContent").innerHTML=`<div class="card question-card"><span class="pill success">МАТЧ ЗАВЕРШЁН</span><h1>${esc(winner)} ${winner==="Ничья"?"":"побеждает!"}</h1><div class="grid two-col"><div class="card"><h3>${esc(state.profiles.p1.name)}</h3><div class="stat-value">${battleScores.p1}</div></div><div class="card"><h3>${esc(state.profiles.p2.name)}</h3><div class="stat-value">${battleScores.p2}</div></div></div><button class="btn" onclick="nav('battle')">Вернуться на арену</button></div>`}
function progressPage(){const p=me();$("#appContent").innerHTML=`<div class="page-intro"><h1>Мой прогресс</h1><p>История занятий, результаты диагностики и накопленный опыт.</p></div><div class="grid stats-grid"><div class="card stat-card"><div class="stat-label">XP</div><div class="stat-value">${p.xp}</div></div><div class="card stat-card"><div class="stat-label">Уроки</div><div class="stat-value">${p.done}</div></div><div class="card stat-card"><div class="stat-label">Диагностика</div><div class="stat-value">${p.diagnostic?p.diagnostic.percent+"%":"—"}</div></div><div class="card stat-card"><div class="stat-label">Целевое время</div><div class="stat-value">60 мин</div></div></div><div class="grid two-col"><div class="card"><h3>Результат диагностики</h3>${p.diagnostic?`<p>Уровень для маршрута: <b>HSK ${p.diagnostic.level}</b></p><p>Правильно: ${p.diagnostic.score}/${p.diagnostic.total}</p><p class="muted">Дата: ${new Date(p.diagnostic.date).toLocaleDateString("ru-RU")}</p>`:`<p class="muted">Пройди входную диагностику, чтобы определить точку старта.</p><button class="btn" onclick="nav('diagnostic')">Пройти тест</button>`}</div><div class="card"><h3>Последние занятия</h3>${p.history.length?p.history.slice(-5).reverse().map(h=>`<div class="task"><div class="task-icon">✓</div><div class="task-info"><b>Учебный блок</b><small>${new Date(h.date).toLocaleString("ru-RU")}</small></div><span>${h.score}/${h.total}</span></div>`).join(""):`<p class="muted">Пока нет завершённых занятий.</p>`}</div></div>`}
function settingsPage(){$("#appContent").innerHTML=`<div class="page-intro"><h1>Настройки</h1><p>Управление локальными профилями и учебным режимом.</p></div><div class="grid two-col"><div class="card"><h3>Профили игроков</h3><label class="muted">Имя игрока 1</label><input class="input-answer" id="name1" value="${esc(state.profiles.p1.name)}"><label class="muted">Имя игрока 2</label><input class="input-answer" id="name2" style="margin-top:8px" value="${esc(state.profiles.p2.name)}"><div class="actions"><button class="btn" onclick="saveNames()">Сохранить имена</button></div></div><div class="card"><h3>Учебный режим</h3><p class="muted">Ежедневная цель: 60 минут. Переход языка: русский → смешанный → преимущественно китайский.</p><span class="pill success">HSK 3.0 основной стандарт</span><p class="muted" style="font-size:12px;margin-top:14px">Совместимость HSK 2.0 будет поддерживаться через таблицу соответствия словаря и тем, а не смешением двух стандартов в одну шкалу.</p><button class="btn ghost" onclick="resetLocal()">Сбросить данные на этом устройстве</button></div></div>`}
function saveNames(){state.profiles.p1.name=$("#name1").value.trim()||"Игрок 1";state.profiles.p2.name=$("#name2").value.trim()||"Игрок 2";save();toast("Имена сохранены");battlePage()}
function resetLocal(){if(confirm("Удалить локальный прогресс обоих игроков на этом устройстве?")){localStorage.removeItem("cb_state");state=structuredClone(initial);save();nav("dashboard")}}
render();
if("serviceWorker" in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));
