# CHINESE BATTLE — Android project (alpha wrapper)

Это Android Studio-проект, который упаковывает текущую веб-версию CHINESE BATTLE в Android-приложение через WebView.

## Что уже включено
- Android Activity и экран приложения
- Локальные HTML/CSS/JS-файлы внутри APK
- Сохранение текущего прогресса через localStorage
- Тёмная тема системных панелей
- Минимальная версия Android 7.0 (API 24)
- GitHub Actions workflow для сборки debug APK

## Сборка в Android Studio
1. Открой папку `CHINESE_BATTLE_Android` в Android Studio.
2. Дождись синхронизации Gradle.
3. Выбери Build → Build Bundle(s) / APK(s) → Build APK(s).
4. APK появится в `app/build/outputs/apk/debug/app-debug.apk`.

## Сборка через GitHub Actions
1. Создай пустой GitHub repository.
2. Загрузи в него все файлы этой папки.
3. Открой вкладку Actions и запусти workflow `Build CHINESE BATTLE APK` (или дождись сборки после push).
4. Скачай artifact `chinese-battle-debug-apk` из завершённого запуска workflow.

## Важные ограничения этой альфа-версии
- Это упаковка текущего прототипа, а не завершённая учебная платформа.
- Два профиля пока локальные на одном устройстве; серверной регистрации и синхронизации нет.
- Учебная база пока небольшая; полный HSK 3.0, аудио, проверка произношения и письма ещё предстоит реализовать.
- Для публикации в Google Play нужен отдельный release build, подпись приложения и аккаунт Google Play Console.
- Для release APK/AAB следует настроить защищённый keystore; не добавляй keystore и пароли в публичный репозиторий.

## Идентификатор приложения
`com.chinesebattle.app`
